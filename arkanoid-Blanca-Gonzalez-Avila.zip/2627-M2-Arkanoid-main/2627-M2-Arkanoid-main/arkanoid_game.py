"""Plantilla del juego Arkanoid para el hito M2.

Completa los métodos marcados con TODO respetando las anotaciones de tipo y la
estructura de la clase. El objetivo es construir un prototipo jugable usando
pygame que cargue bloques desde un fichero de nivel basado en caracteres.
"""
from arkanoid_core import *
from math import sqrt
from pathlib import Path
# --------------------------------------------------------------------- #
# Métodos a completar por el alumnado
# --------------------------------------------------------------------- #

@arkanoid_method
def cargar_nivel(self) -> list[str]:
    """Lee el fichero de nivel y devuelve la cuadrícula como lista de filas."""
    # - Comprueba que `self.level_path` existe y es fichero.
    # - Lee su contenido, filtra líneas vacías y valida que todas tienen el mismo ancho.
    # - Guarda el resultado en `self.layout` y devuélvelo.
    if self.level_path.exists():
        print("El fichero existe")
    else:
        print("El fichero no existe")

    lectura = [
        fila.strip()
        for fila in self.level_path.read_text().splitlines()
        if fila.strip()
    ]
    if not lectura:
        raise ValueError("El nivel está vacío")

    ancho = len(lectura[0])
    if any(len(fila) != ancho for fila in lectura):
        raise ValueError("Las líneas del fichero no tienen el mismo ancho")
    self.layout=lectura
    return self.layout

@arkanoid_method
def preparar_entidades(self) -> None:
    """Posiciona paleta y bola, y reinicia puntuación y vidas."""
    # - Ajusta el tamaño de `self.paddle` y céntrala usando `midbottom`.
    # - Reinicia `self.score`, `self.lives` y `self.end_message`.
    # - Llama a `self.reiniciar_bola()` para colocar la bola sobre la paleta.
    self.paddle. midbottom=((self.SCREEN_WIDTH//2)-(self.PADDLE_SIZE[0]//2), self.SCREEN_HEIGHT-self.PADDLE_OFFSET)
    ball_position=self.reiniciar_bola()
    self.score=0
    self.lives=5
    self.end_message=""

@arkanoid_method
def crear_bloques(self) -> None:
    """Genera los rectángulos de los bloques en base a la cuadrícula."""
    # - Limpia `self.blocks`, `self.block_colors` y `self.block_symbols`.
    # - Recorre `self.layout` para detectar símbolos de bloque.
    # - Usa `self.calcular_posicion_bloque` y rellena las listas paralelas.
    self.blocks.clear()
    self.block_colors.clear()
    self.block_symbols.clear()
    for fila, linea in enumerate(self.layout):
        for columna, simbolo in enumerate(linea):
            if simbolo in self.BLOCK_COLORS:
                bloque = self.calcular_posicion_bloque(fila, columna)
                self.blocks.append(bloque)
                self.block_colors.append(self.BLOCK_COLORS[simbolo])
                self.block_symbols.append(simbolo)

@arkanoid_method
def procesar_input(self) -> None:
    """Gestiona la entrada de teclado para mover la paleta."""
    # - Obtén el estado de teclas con `self.obtener_estado_teclas()`.
    # - Desplaza la paleta con `self.PADDLE_SPEED` si se pulsan las teclas izquierda/derecha.
    # - Limita la posición para que no salga de la pantalla.
    teclas = self.obtener_estado_teclas()
    if teclas[self.KEY_LEFT]:
        self.paddle.x -= self.PADDLE_SPEED
    if teclas[self.KEY_RIGHT]:
        self.paddle.x += self.PADDLE_SPEED
    if self.paddle.x <0:
        self.paddle.x=0
    if self.paddle.x > self.SCREEN_WIDTH-self.PADDLE_SIZE[0]:
        self.paddle.x=self.SCREEN_WIDTH-self.PADDLE_SIZE[0]

@arkanoid_method
def actualizar_bola(self) -> None:
    """Actualiza la posición de la bola y resuelve colisiones."""
    # - Suma `self.ball_velocity` a `self.ball_pos` y genera `ball_rect` con `self.obtener_rect_bola()`.
    # - Gestiona rebotes con paredes, paleta y bloques, modificando velocidad y puntuación.
    # - Controla fin de nivel cuando no queden bloques y resta vidas si la bola cae.
    previous_rect = self.obtener_rect_bola()
    self.ball_pos += self.ball_velocity
    ball_rect = self.obtener_rect_bola()
    if ball_rect.left < 0 or ball_rect.right > self.SCREEN_WIDTH:#bordes de la pantalla. Choque con las paredes
        self.ball_velocity.x *= -1
    if ball_rect.top < 0:#choque con el techo
        self.ball_velocity.y *= -1
    if ball_rect.bottom > self.SCREEN_HEIGHT:
        self.lives -= 1
        if self.lives > 0:
            self.reiniciar_bola()
        else:
            self.end_message = "GAME OVER"
    if ball_rect.colliderect(self.paddle) and self.ball_velocity.y > 0:
        desvio = (self.ball_pos.x - self.paddle.centerx) / (self.paddle.width / 2)
        desvio = max(-0.8, min(0.8, desvio))

        self.ball_velocity.x = desvio * self.BALL_SPEED
        self.ball_velocity.y = -sqrt(self.BALL_SPEED**2 - self.ball_velocity.x**2)

    bloque_index = ball_rect.collidelist(self.blocks)
    if bloque_index >= 0:
        bloque = self.blocks[bloque_index]
        simbolo_bloque = self.block_symbols[bloque_index]

        if previous_rect.bottom <= bloque.top or previous_rect.top >= bloque.bottom:
            self.ball_velocity.y *= -1
            if self.ball_velocity.y > 0:
                self.ball_pos.y = bloque.bottom + self.BALL_RADIUS
            else:
                self.ball_pos.y = bloque.top - self.BALL_RADIUS
        elif previous_rect.right <= bloque.left or previous_rect.left >= bloque.right:
            self.ball_velocity.x *= -1
            if self.ball_velocity.x > 0:
                self.ball_pos.x = bloque.right + self.BALL_RADIUS
            else:
                self.ball_pos.x = bloque.left - self.BALL_RADIUS
        else:
            overlap_x = min(ball_rect.right, bloque.right) - max(ball_rect.left, bloque.left)
            overlap_y = min(ball_rect.bottom, bloque.bottom) - max(ball_rect.top, bloque.top)
            if overlap_x < overlap_y:
                self.ball_velocity.x *= -1
            else:
                self.ball_velocity.y *= -1

        self.score += self.BLOCK_POINTS[simbolo_bloque]
        self.blocks.pop(bloque_index)
        self.block_colors.pop(bloque_index)
        self.block_symbols.pop(bloque_index)

        if not self.blocks:
            self.end_message = "Felicidades"

@arkanoid_method
def dibujar_escena(self) -> None:
    """Renderiza fondo, bloques, paleta, bola y HUD."""
    # - Rellena el fondo y dibuja cada bloque con `self.dibujar_rectangulo`.
    # - Pinta la paleta y la bola con las utilidades proporcionadas.
    # - Muestra puntuación, vidas y mensajes usando `self.dibujar_texto`.
    self.screen.fill((12, 20, 32))
    for bloque, color in zip(self.blocks, self.block_colors):#zip (lista de listas)
        self.dibujar_rectangulo(bloque, color)#recorre cada uno de esos elementos de esas listas invididualmente y los conecta
    self.dibujar_rectangulo(self.paddle, (230, 230, 240))
    self.dibujar_circulo(self.ball_pos, self.BALL_RADIUS, (255, 245, 235))
    self.dibujar_texto(f"Puntuación: {self.score}", (10, 10))
    self.dibujar_texto(f"Vidas: {self.lives}", (10, 40))
    if self.end_message:
        self.dibujar_texto(
            self.end_message,
            (self.SCREEN_WIDTH // 2 - 250, self.SCREEN_HEIGHT // 2),
            grande=True,
        )
        if self.end_message == "GAME OVER":
            self.dibujar_texto(
                "Pulsa Esc para cerrar",
                (self.SCREEN_WIDTH // 2 - 130, self.SCREEN_HEIGHT // 2 + 55),
            )

@arkanoid_method
def run(self) -> None:
    """Ejecuta el bucle principal del juego."""
    # - Inicializa recursos (`self.inicializar_pygame`, `self.cargar_nivel`, etc.).
    # - Procesa eventos de `self.iterar_eventos()` y llama a los métodos de actualización/dibujo.
    # - Refresca la pantalla con `self.actualizar_pantalla()` y cierra con `self.finalizar_pygame()`.
    self.inicializar_pygame()
    self.cargar_nivel()
    self.preparar_entidades()
    self.crear_bloques()
    if not self.blocks:
        self.end_message = "¡Felicidades! ¡Has ganado!"
    self.running = True
    try:
        while self.running:
            for evento in self.iterar_eventos():
                if evento.type == self.EVENT_QUIT or (
                    evento.type == self.EVENT_KEYDOWN and evento.key == self.KEY_ESCAPE
                ):
                    self.running = False

            if not self.running:
                break

            if not self.end_message:
                self.procesar_input()
                self.actualizar_bola()
            self.dibujar_escena()
            self.actualizar_pantalla()
            self.clock.tick(self.FPS)
    finally:
        self.finalizar_pygame()

def main() -> None:
    """Permite ejecutar el juego desde la línea de comandos."""
    import argparse

    parser = argparse.ArgumentParser(
        description="Plantilla del hito M2: Arkanoid con pygame.",
    )
    parser.add_argument(
        "level",
        type=str,
        nargs="?",
        default=str(Path(__file__).resolve().parent / "niveles" / "demo.txt"),
        help="Ruta al fichero de nivel (texto con # para bloques y . para huecos).",
    )
    args = parser.parse_args()

    game = ArkanoidGame(args.level)
    game.run()


if __name__ == "__main__":
    main()
